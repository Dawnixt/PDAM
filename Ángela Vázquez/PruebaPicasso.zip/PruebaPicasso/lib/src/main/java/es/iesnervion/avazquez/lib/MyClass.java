package es.iesnervion.avazquez.lib;

public class MyClass {
}
